<?php
require_once __DIR__ . '/../db/config.php';
require_once __DIR__ . '/../db/controlleur.php';

$c=new controlleur(config::getConnexion());

$c->deleteUser($_POST['user_id']);

header("location: ../index.php");

?>