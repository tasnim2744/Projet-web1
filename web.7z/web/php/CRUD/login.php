<?php
session_start();
require_once __DIR__ . '/../db/config.php';

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../../login_member.php');
    exit;
}

$identifier = trim($_POST['identifier'] ?? '');
$password = $_POST['password'] ?? '';

try {
    $db = config::getConnexion();
    $stmt = $db->prepare("SELECT * FROM user WHERE username = :ident OR email = :ident LIMIT 1");
    $stmt->execute(['ident' => $identifier]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        header('Location: ../../login_member.php?error=notfound');
        exit;
    }

    $stored = $user['password'];
    $ok = false;

    // support both hashed and plaintext passwords
    if (password_verify($password, $stored)) {
        $ok = true;
    } elseif ($password === $stored) {
        $ok = true;
    }

    if ($ok) {
        // set session and redirect
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['username'] = $user['username'];
            echo'shit done🗿🗿🗿';
        header('Location: ../../index.php');
        exit;
    } else {
        header('Location: ../../login_member.php?error=invalid');
        exit;
    }
} catch (Exception $e) {
    // Fail gracefully — in production log this instead
    header('Location: ../../login_member.php?error=server');
            echo'🗿🗿🗿SHITTTTTT';
    exit;
}
?>