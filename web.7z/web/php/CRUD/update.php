<?php
require_once __DIR__ . "/../db/controlleur.php";

$c=new controlleur();










?>