
<?php
require_once __DIR__ . '/../db/config.php';
require_once __DIR__ . '/../db/controlleur.php';
require_once __DIR__ . '/../user.php';

$c=new controlleur(config::getConnexion());

//$hashed = password_hash($_POST['password'], PASSWORD_DEFAULT);

$u= new user(
    NULL,
    $_POST['username'],
    $_POST['email'],
    $_POST['password'],
    $_POST['role'],
    $_POST['created_at']
);
$c->addUser($u);

header("location: ../../index.php");





?>