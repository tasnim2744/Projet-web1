<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/../user.php';

class controlleur {
    private $db;
    public function __construct($db) {
        $this->db = config::getConnexion();
    }
//LISTTTT
    public function listUser(){
        $q=$this->db->query("SELECT * from user;");
        return $q->fetchAll();
    }
//Addd
    public function addUser(user $u){
        $sql="INSERT into user Values(NULL,:username,:email,:password,:role,:created_at);";
        $db=config::getConnexion();
        $query = $db->prepare($sql);
        try{
            $query->execute([
            'username'=>$u->getUsername(),
            'email'=>$u->getEmail(),
            'password'=>$u->getPassword(),
            'role'=>$u->getRole(),
            'created_at'=>$u->getCreatedAt()     
        ]); 
            echo'shit done🗿🗿🗿';
        }
        catch(Exception $e){
            echo 'err' . $e->getMessage();
        }
    }
//DELETEEE
    public function deleteUser(user $u){
        $sql="DELETE FROM user where user_id= :id ";
        $db=config::getConnexion();
        $req=$db->prepare($sql);
        try{
            $req->execute([":id" => $u->getId()]);
            echo'shit done🗿🗿🗿';
        }
        catch(Exception $e){
            echo 'err' . $e->getMessage();
        }
    } 
//UPADATEEEE
    public function updateUser(user $u){
        $sql="UPDATE user SET username=:us,email=:m ,password=:ps,role=:r,created_at=:ca";
        $db=config::getConnexion();
        $req=$db->prepare($sql);
        try{
            $req->execute([
                'us'=>$u->getUsername(),
                'm'=>$u->getEmail(),
                'ps'=>$u->getPassword(),
                'r'=>$u->getRole(),
                'ca'=>$u->getCreatedAt()
            ]);
            echo'shit done🗿🗿🗿';
        }
        catch(Exception $e){
            echo 'err' . $e->getMessage();
        }

    }
}



?>