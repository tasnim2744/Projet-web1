<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Add User</title>
</head>

<body>

<header>
    <div class="container">
        <h1 class="logo">Peace Connect</h1>
    </div>
</header>

<div class="container" style="margin-top:150px;">
    <div class="card">

        <h2 >Add New User</h2>

        <form method="POST" action="php/CRUD/add.php">

            <div class="input-row">
                <input type="text" name="username" placeholder="username" required>
            </div>

            <input type="email" name="email" placeholder="Email" ><br><br>
            <input type="password" name="password" placeholder="Password" ><br><br>

            <input type="text" name="role" value="client" placeholder="Role"><br><br>
            <input type="date" name="created_at" id="">
            <button class="shop-now-btn" type="submit">Add User</button>
        </form>

        <br>
        <a href="index.php" class="shop-now-btn">Back</a>

    </div>
</div>

</body>
</html>
