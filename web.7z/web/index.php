<?php
// Welcome/home page
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Peace Connect - Home</title>
    <link rel="stylesheet" href="js+css/main.css">
    <link rel="stylesheet" href="js+css/responsive.css">
</head>
<body>
    <header>
        <div class="container">
            <h1 class="logo">Peace Connect</h1>
        </div>
    </header>

    <div class="container" style="margin-top:150px;">
        <div class="card">
            <h2>Welcome to Peace Connect</h2>
            <p>
                <a href="login_member.php" class="shop-now-btn">Login</a>
                <a href="registre_member.php" class="shop-now-btn">Register</a>
            </p>
        </div>
    </div>

    <script src="js+css/main.js"></script>
</body>
</html>
