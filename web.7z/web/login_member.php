<?php
// Simple login form — posts to php/CRUD/login.php
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Member Login - Peace Connect</title>
</head>
<body>

<header>
    <div class="container">
        <h1 class="logo">Peace Connect</h1>
    </div>
</header>

<div class="container" style="margin-top:150px;">
    <div class="card">

        <h2>Member Login</h2>

        <form method="POST" action="php/CRUD/login.php">

            <div class="input-row">
                <input type="text" name="identifier" placeholder="Username or Email" required>
            </div>

            <input type="password" name="password" placeholder="Password" required><br><br>

            <button class="shop-now-btn" type="submit">Login</button>
        </form>

        <br>
        <a href="index.php" class="shop-now-btn">Back</a>

    </div>
</div>

</body>
</html>
